import math

def opFrequencia():
    print("em construção")
def opCompOnda():
    print("em construção")
def opNumOnda():
    print("em construção")
def opFreAng():
    print("em construção")
def opCampMag():
    while True: 
        print("--Menu--")
        print("2 - Fazer Exercicios")
        print("1 - Desenvolvedores")
        print("0 - Sair")

        i = int(input(""))

        if i == 0:  
            break
        elif i == 1:
            print("em construção")
        elif i == 2:
            print("em construção")
        else:
            print("Opação invalida")